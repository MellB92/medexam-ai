#!/usr/bin/env python3
"""
MedExamAI - Dateisortierung und Konfidenz-Suche
===============================================
Dieses Skript:
1. Sucht alle Dateien mit "Konfidenz" (echte Antworten)
2. Sortiert Dateien in Kategorien
3. Erstellt einen Bericht über den aktuellen Zustand
4. Bereitet das System für die Antwort-Generierung vor

Ausführung: python3 sortiere_und_finde_konfidenz.py
"""

import os
import re
import json
import shutil
from datetime import datetime
from pathlib import Path
from collections import defaultdict

# Konfiguration
BASE_DIR = Path.home() / "Documents" / "Medexamenai"
OUTPUT_DIR = BASE_DIR / "_SORTIERUNG_ERGEBNIS"
BACKUP_DIR = BASE_DIR / "_WIEDERHERSTELLUNGS_BACKUPS"

def find_konfidenz_files(base_dir):
    """Sucht alle Dateien mit 'Konfidenz' im Inhalt"""
    konfidenz_files = []
    
    for root, dirs, files in os.walk(base_dir):
        # Skip versteckte Ordner und venv
        dirs[:] = [d for d in dirs if not d.startswith('.') and d != 'venv' and d != '__pycache__']
        
        for file in files:
            if file.endswith(('.json', '.md', '.txt')):
                filepath = Path(root) / file
                try:
                    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                    
                    # Suche nach Konfidenz-Pattern
                    konfidenz_matches = re.findall(r'\*?Konfidenz[:\s]*[✅❌]?\s*\d+%', content, re.IGNORECASE)
                    
                    if konfidenz_matches:
                        # Zähle Antworten
                        count = len(konfidenz_matches)
                        konfidenz_files.append({
                            'path': str(filepath),
                            'name': file,
                            'count': count,
                            'size_kb': filepath.stat().st_size / 1024,
                            'modified': datetime.fromtimestamp(filepath.stat().st_mtime).isoformat()
                        })
                except Exception as e:
                    pass
    
    return sorted(konfidenz_files, key=lambda x: x['count'], reverse=True)

def categorize_files(base_dir):
    """Kategorisiert alle Dateien im Projekt"""
    categories = {
        'GOLD_STANDARD': [],      # Original-Protokolle
        'GENERIERTE_ANTWORTEN': [], # Dateien mit Konfidenz
        'FRAGEN_EXTRAKTION': [],  # frage_bloecke etc.
        'WIEDERHERSTELLUNG': [],  # Backup/Recovery-Dateien
        'SCRIPTS': [],            # Python-Skripte
        'DOKUMENTATION': [],      # Berichte, READMEs
        'ANDERE': []
    }
    
    wiederherstellung_keywords = [
        'backup', 'recover', 'restore', 'checkpoint', 'tmp', 'temp',
        'before_', '_backup', '_recovered', '_restored', 'old_'
    ]
    
    gold_standard_keywords = [
        'Kenntnisprüfung', 'Protokoll', 'Münster', 'KP ', 'Strahlenschutz',
        'Rechtsmedizin', '_GOLD_STANDARD'
    ]
    
    for root, dirs, files in os.walk(base_dir):
        dirs[:] = [d for d in dirs if not d.startswith('.') and d != 'venv']
        
        for file in files:
            filepath = Path(root) / file
            rel_path = str(filepath.relative_to(base_dir))
            
            file_info = {
                'path': str(filepath),
                'relative': rel_path,
                'name': file,
                'size_kb': filepath.stat().st_size / 1024 if filepath.exists() else 0
            }
            
            # Kategorisierung
            if file.endswith('.py'):
                categories['SCRIPTS'].append(file_info)
            elif any(kw.lower() in file.lower() or kw.lower() in rel_path.lower() 
                    for kw in wiederherstellung_keywords):
                categories['WIEDERHERSTELLUNG'].append(file_info)
            elif '_GOLD_STANDARD' in rel_path or any(kw in file for kw in gold_standard_keywords):
                categories['GOLD_STANDARD'].append(file_info)
            elif 'frage_bloecke' in file.lower() or 'questions' in file.lower():
                categories['FRAGEN_EXTRAKTION'].append(file_info)
            elif file.endswith(('.md', '.txt')) and 'README' in file.upper():
                categories['DOKUMENTATION'].append(file_info)
            elif file.endswith('.json') or file.endswith('.md'):
                # Prüfe auf Konfidenz
                try:
                    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                        if 'Konfidenz' in f.read():
                            categories['GENERIERTE_ANTWORTEN'].append(file_info)
                        else:
                            categories['ANDERE'].append(file_info)
                except:
                    categories['ANDERE'].append(file_info)
            else:
                categories['ANDERE'].append(file_info)
    
    return categories

def extract_konfidenz_answers(konfidenz_files):
    """Extrahiert alle Antworten mit Konfidenz-Marker"""
    all_answers = []
    
    for file_info in konfidenz_files:
        filepath = file_info['path']
        
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            if filepath.endswith('.md'):
                # MD-Format: ## Frage X ... *Konfidenz: X%*
                pattern = r'## (?:Frage \d+|\d+\.)\s*\n+\*\*(.+?)\*\*.*?### Antwort\s*\n(.+?)\*Konfidenz[:\s]*([✅❌]?)\s*(\d+)%\*'
                matches = re.findall(pattern, content, re.DOTALL)
                
                for match in matches:
                    all_answers.append({
                        'frage': match[0].strip()[:200],
                        'antwort': match[1].strip()[:1000],
                        'konfidenz_status': match[2],
                        'konfidenz_prozent': int(match[3]),
                        'source_file': os.path.basename(filepath)
                    })
            
            elif filepath.endswith('.json'):
                # JSON-Format
                data = json.loads(content)
                if isinstance(data, list):
                    for item in data:
                        if 'konfidenz' in str(item).lower():
                            all_answers.append({
                                'frage': item.get('frage', item.get('question', ''))[:200],
                                'antwort': item.get('antwort', item.get('answer', ''))[:1000],
                                'konfidenz_prozent': item.get('konfidenz', item.get('confidence', 0)),
                                'source_file': os.path.basename(filepath)
                            })
        except Exception as e:
            print(f"  Fehler bei {filepath}: {e}")
    
    return all_answers

def create_report(konfidenz_files, categories, answers):
    """Erstellt einen umfassenden Bericht"""
    
    report = f"""# MedExamAI - Sortierungs- und Konfidenz-Bericht

**Erstellt:** {datetime.now().strftime('%Y-%m-%d %H:%M')}
**Basis-Verzeichnis:** {BASE_DIR}

---

## 1. Dateien mit "Konfidenz" (Echte generierte Antworten)

| Datei | Anzahl Antworten | Größe |
|-------|------------------|-------|
"""
    
    total_konfidenz = 0
    for f in konfidenz_files[:20]:
        report += f"| {f['name']} | {f['count']} | {f['size_kb']:.1f} KB |\n"
        total_konfidenz += f['count']
    
    report += f"\n**Gesamt: {total_konfidenz} Antworten mit Konfidenz-Marker in {len(konfidenz_files)} Dateien**\n"
    
    report += f"""
---

## 2. Datei-Kategorisierung

"""
    
    for category, files in categories.items():
        if files:
            report += f"### {category} ({len(files)} Dateien)\n\n"
            for f in files[:10]:
                report += f"- `{f['relative']}`\n"
            if len(files) > 10:
                report += f"- ... und {len(files) - 10} weitere\n"
            report += "\n"
    
    report += f"""
---

## 3. Extrahierte Antworten (Stichprobe)

Gesamt extrahiert: **{len(answers)} Antworten**

### Qualitätsverteilung nach Konfidenz:

"""
    
    # Konfidenz-Verteilung
    high = sum(1 for a in answers if a.get('konfidenz_prozent', 0) >= 70)
    medium = sum(1 for a in answers if 30 <= a.get('konfidenz_prozent', 0) < 70)
    low = sum(1 for a in answers if a.get('konfidenz_prozent', 0) < 30)
    
    report += f"""| Konfidenz | Anzahl | Prozent |
|-----------|--------|---------|
| 🟢 Hoch (≥70%) | {high} | {100*high/len(answers) if answers else 0:.1f}% |
| 🟡 Mittel (30-69%) | {medium} | {100*medium/len(answers) if answers else 0:.1f}% |
| 🔴 Niedrig (<30%) | {low} | {100*low/len(answers) if answers else 0:.1f}% |

---

## 4. Empfehlungen

### Für die Fortsetzung der Antwort-Generierung:

1. **Nutze diese Dateien als Basis:**
"""
    
    for f in konfidenz_files[:5]:
        report += f"   - `{f['name']}` ({f['count']} Antworten)\n"
    
    report += f"""
2. **Ignoriere/Archiviere Wiederherstellungs-Dateien:**
   - {len(categories.get('WIEDERHERSTELLUNG', []))} Dateien können in `_WIEDERHERSTELLUNGS_BACKUPS` verschoben werden

3. **Starte Generierung ab Frage:**
   - Letzte beantwortete Frage: ca. #{total_konfidenz}
   - Noch zu generieren: ca. {2689 - total_konfidenz} Fragen

---

## 5. Nächste Schritte

```bash
# 1. Führe dedupe_questions.py aus, um die 2.689 Fragen zu regenerieren
python3 scripts/dedupe_questions.py --input _EXTRACTED_FRAGEN/frage_bloecke.json --output _EXTRACTED_FRAGEN/fragen_dedupliziert.json

# 2. Starte Generierung mit --resume
python3 scripts/generate_evidenz_answers.py --resume --start-from {total_konfidenz}
```

"""
    
    return report

def main():
    print("=" * 60)
    print("MedExamAI - Dateisortierung und Konfidenz-Suche")
    print("=" * 60)
    
    if not BASE_DIR.exists():
        print(f"❌ Verzeichnis nicht gefunden: {BASE_DIR}")
        print("   Bitte passe BASE_DIR im Skript an.")
        return
    
    # 1. Suche Konfidenz-Dateien
    print("\n📁 Suche nach Dateien mit 'Konfidenz'...")
    konfidenz_files = find_konfidenz_files(BASE_DIR)
    print(f"   ✅ Gefunden: {len(konfidenz_files)} Dateien")
    
    for f in konfidenz_files[:10]:
        print(f"      - {f['name']}: {f['count']} Antworten")
    
    # 2. Kategorisiere alle Dateien
    print("\n📂 Kategorisiere Dateien...")
    categories = categorize_files(BASE_DIR)
    for cat, files in categories.items():
        print(f"   {cat}: {len(files)} Dateien")
    
    # 3. Extrahiere Antworten
    print("\n📝 Extrahiere Konfidenz-Antworten...")
    answers = extract_konfidenz_answers(konfidenz_files)
    print(f"   ✅ Extrahiert: {len(answers)} Antworten")
    
    # 4. Erstelle Output-Verzeichnis
    OUTPUT_DIR.mkdir(exist_ok=True)
    
    # 5. Erstelle Bericht
    print("\n📄 Erstelle Bericht...")
    report = create_report(konfidenz_files, categories, answers)
    
    report_path = OUTPUT_DIR / "SORTIERUNGS_BERICHT.md"
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(report)
    print(f"   ✅ Bericht: {report_path}")
    
    # 6. Speichere extrahierte Antworten
    answers_path = OUTPUT_DIR / "konfidenz_antworten.json"
    with open(answers_path, 'w', encoding='utf-8') as f:
        json.dump(answers, f, ensure_ascii=False, indent=2)
    print(f"   ✅ Antworten: {answers_path}")
    
    # 7. Speichere Konfidenz-Dateien-Liste
    files_path = OUTPUT_DIR / "konfidenz_dateien.json"
    with open(files_path, 'w', encoding='utf-8') as f:
        json.dump(konfidenz_files, f, ensure_ascii=False, indent=2)
    print(f"   ✅ Dateien-Liste: {files_path}")
    
    # 8. Frage nach Archivierung
    print("\n" + "=" * 60)
    print("ZUSAMMENFASSUNG")
    print("=" * 60)
    print(f"✅ Konfidenz-Dateien: {len(konfidenz_files)}")
    print(f"✅ Extrahierte Antworten: {len(answers)}")
    print(f"⚠️ Wiederherstellungs-Dateien: {len(categories.get('WIEDERHERSTELLUNG', []))}")
    
    total_answers = sum(f['count'] for f in konfidenz_files)
    print(f"\n📊 Geschätzte beantwortete Fragen: {total_answers}")
    print(f"📊 Noch zu generieren (von 2.689): ca. {2689 - total_answers}")
    
    print(f"\n📁 Ergebnisse gespeichert in: {OUTPUT_DIR}")
    print("\nMöchtest du die Wiederherstellungs-Dateien archivieren?")
    print("Führe dazu aus: python3 sortiere_und_finde_konfidenz.py --archive")

if __name__ == "__main__":
    import sys
    
    if "--archive" in sys.argv:
        print("Archivierung der Wiederherstellungs-Dateien...")
        BACKUP_DIR.mkdir(exist_ok=True)
        categories = categorize_files(BASE_DIR)
        
        for f in categories.get('WIEDERHERSTELLUNG', []):
            src = Path(f['path'])
            dst = BACKUP_DIR / f['name']
            if src.exists():
                shutil.move(str(src), str(dst))
                print(f"  Verschoben: {f['name']}")
        
        print(f"\n✅ Archiviert in: {BACKUP_DIR}")
    else:
        main()
